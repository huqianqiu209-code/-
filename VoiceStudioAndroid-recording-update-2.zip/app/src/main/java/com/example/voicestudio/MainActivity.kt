package com.example.voicestudio

import android.Manifest
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { VoiceStudioScreen() } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun VoiceStudioScreen() {
    val context = LocalContext.current
    var recording by remember { mutableStateOf(false) }
    var outputBytes by remember { mutableStateOf<ByteArray?>(null) }
    var modelUris by remember { mutableStateOf(listOf<Uri>()) }
    var status by remember { mutableStateOf("准备就绪。点击开始录音并允许麦克风权限。") }
    var player by remember { mutableStateOf<MediaPlayer?>(null) }
    var recorder by remember { mutableStateOf<AudioRecord?>(null) }
    var recordingThread by remember { mutableStateOf<Thread?>(null) }
    val stopFlag = remember { AtomicBoolean(false) }

    val modelPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            uris.forEach { try { context.contentResolver.takePersistableUriPermission(it, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {} }
            modelUris = (modelUris + uris).distinct()
            status = "已选择 ${modelUris.size} 个模型/辅助文件。选择文件不代表模型已兼容。"
        }
    }
    val exportPicker = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("audio/wav")) { uri ->
        val bytes = outputBytes
        if (uri != null && bytes != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { it.write(bytes) } ?: error("无法写入文件")
                status = "WAV 导出完成。"
            } catch (e: Exception) { status = "导出失败：${e.message}" }
        }
    }

    fun startRecording() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            status = "请先授予麦克风权限。"
            return
        }
        val sampleRate = 44100
        val minBuffer = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minBuffer <= 0) { status = "此设备不支持所需录音格式。"; return }
        try {
            val audioRecord = AudioRecord(MediaRecorder.AudioSource.MIC, sampleRate, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuffer, sampleRate))
            if (audioRecord.state != AudioRecord.STATE_INITIALIZED) { audioRecord.release(); status = "无法初始化麦克风。"; return }
            val pcm = ByteArrayOutputStream()
            val buffer = ByteArray(maxOf(minBuffer, 4096))
            stopFlag.set(false)
            audioRecord.startRecording()
            recorder = audioRecord
            recording = true
            outputBytes = null
            status = "正在录音…点击停止录音结束。"
            recordingThread = Thread {
                try {
                    while (!stopFlag.get()) {
                        val count = audioRecord.read(buffer, 0, buffer.size)
                        if (count > 0) pcm.write(buffer, 0, count)
                    }
                } catch (_: Exception) { }
                try { audioRecord.stop() } catch (_: Exception) { }
                audioRecord.release()
                val wav = makeWav(pcm.toByteArray(), sampleRate, 1, 16)
                outputBytes = wav
                recording = false
                recorder = null
                recordingThread = null
                status = "录音完成。可试听或导出 WAV。注意：当前尚未执行 AI 变声。"
            }.also { it.start() }
        } catch (e: Exception) { status = "启动录音失败：${e.message}"; recording = false }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startRecording() else status = "未授予麦克风权限，无法录音。可在系统设置中允许麦克风权限后重试。"
    }

    fun stopRecording() {
        stopFlag.set(true)
        status = "正在结束录音并生成 WAV…"
    }

    DisposableEffect(Unit) {
        onDispose {
            stopFlag.set(true)
            try { recorder?.stop() } catch (_: Exception) { }
            try { recorder?.release() } catch (_: Exception) { }
            player?.release()
        }
    }

    Scaffold(topBar = { TopAppBar(title = { Text("Voice Studio", fontWeight = FontWeight.Bold) }) }) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text("录音变声工作台", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("本地录音 · 离线处理 · Android 12+", color = MaterialTheme.colorScheme.onSurfaceVariant)
            ElevatedCard {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Mic, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("麦克风录音", style = MaterialTheme.typography.titleMedium)
                    }
                    Text(if (recording) "正在录音" else if (outputBytes != null) "已有录音，可试听或导出" else "尚未录音", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (!recording) {
                        Button(onClick = {
                            if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startRecording()
                            else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.Mic, null); Spacer(Modifier.width(8.dp)); Text("开始录音")
                        }
                    } else {
                        Button(onClick = { stopRecording() }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.Stop, null); Spacer(Modifier.width(8.dp)); Text("停止录音")
                        }
                    }
                    OutlinedButton(enabled = outputBytes != null && !recording, onClick = {
                        try {
                            val temp = File(context.cacheDir, "voice_studio_preview.wav")
                            temp.writeBytes(outputBytes!!)
                            player?.release()
                            player = MediaPlayer().apply {
                                setDataSource(temp.absolutePath)
                                setOnPreparedListener { it.start(); status = "正在试听录音。" }
                                setOnCompletionListener { status = "试听完成。" }
                                prepareAsync()
                            }
                        } catch (e: Exception) { status = "试听失败：${e.message}" }
                    }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(8.dp)); Text("试听录音") }
                }
            }
            ElevatedCard {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.FolderOpen, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("变声模型", style = MaterialTheme.typography.titleMedium)
                    }
                    Text(if (modelUris.isEmpty()) "未选择模型文件" else modelUris.joinToString("\n") { DocumentFile.fromSingleUri(context, it)?.name ?: it.lastPathSegment ?: "模型文件" }, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    OutlinedButton(onClick = { modelPicker.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth()) { Text("选择模型文件（ONNX / PTH / INDEX）") }
                    Text("模型文件选择功能已保留；当前版本尚未接入 RVC 推理引擎，因此不会生成虚假的 AI 变声结果。", style = MaterialTheme.typography.bodySmall)
                }
            }
            Button(enabled = outputBytes != null && !recording, onClick = {
                status = "录音已准备好，但 RVC 推理引擎尚未接入，暂不能进行 AI 变声。"
            }, modifier = Modifier.fillMaxWidth()) { Text("开始 AI 变声（引擎待接入）") }
            OutlinedButton(enabled = outputBytes != null && !recording, onClick = { exportPicker.launch("voice_studio_recording.wav") }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Save, null); Spacer(Modifier.width(8.dp)); Text("导出 WAV")
            }
            Surface(color = MaterialTheme.colorScheme.secondaryContainer, shape = MaterialTheme.shapes.medium) {
                Text(status, Modifier.fillMaxWidth().padding(14.dp), color = MaterialTheme.colorScheme.onSecondaryContainer)
            }
            Text("隐私：录音在本机处理，不会由本应用上传。", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

private fun makeWav(pcm: ByteArray, sampleRate: Int, channels: Int, bitsPerSample: Int): ByteArray {
    val out = ByteArrayOutputStream(44 + pcm.size)
    fun writeAscii(s: String) = out.write(s.toByteArray(Charsets.US_ASCII))
    fun writeInt(v: Int) { out.write(v and 0xff); out.write((v shr 8) and 0xff); out.write((v shr 16) and 0xff); out.write((v shr 24) and 0xff) }
    fun writeShort(v: Int) { out.write(v and 0xff); out.write((v shr 8) and 0xff) }
    writeAscii("RIFF"); writeInt(36 + pcm.size); writeAscii("WAVE"); writeAscii("fmt "); writeInt(16)
    writeShort(1); writeShort(channels); writeInt(sampleRate); writeInt(sampleRate * channels * bitsPerSample / 8)
    writeShort(channels * bitsPerSample / 8); writeShort(bitsPerSample); writeAscii("data"); writeInt(pcm.size); out.write(pcm)
    return out.toByteArray()
}
