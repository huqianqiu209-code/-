# Voice Studio Android

Android app for local microphone recording, playback, and WAV export.

## Build with GitHub Actions

1. Upload the contents of this project to the root of a GitHub repository.
2. Open **Actions** and run **Build VoiceStudioAndroid APK**, or push to `main`/`master`.
3. Download the `VoiceStudioAndroid-debug-apk` artifact from the workflow run.

## Current status

- Microphone permission and PCM recording: implemented.
- Local playback and WAV export: implemented.
- Model file selection: implemented.
- RVC inference: **not yet implemented**. Selecting `.pth`, `.index`, or `.onnx` files does not perform voice conversion. A compatible inference runtime and supporting models must be integrated separately.
